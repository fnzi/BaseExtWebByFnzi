/**
 * Internal implementations and support around "current session" handling.
 */
package org.hibernate.context.internal;
