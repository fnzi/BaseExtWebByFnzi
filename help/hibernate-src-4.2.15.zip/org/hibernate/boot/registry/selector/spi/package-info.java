/**
 * SPI package for the {@link org.hibernate.boot.registry.selector.spi.StrategySelector} service.
 */
package org.hibernate.boot.registry.selector.spi;
